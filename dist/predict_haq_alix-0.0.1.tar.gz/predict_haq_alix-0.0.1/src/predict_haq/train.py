import os
import sys
root_dir = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, root_dir)


import urllib.request
from types import SimpleNamespace
from urllib.error import HTTPError
import pandas as pd
import lightning as L
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import torchvision
from IPython.display import HTML, display
from lightning.pytorch.callbacks import LearningRateMonitor, ModelCheckpoint
from PIL import Image
from torchvision import transforms
from pathlib import Path
from predict_haq.model import DenseNetModel



class XrayDataset(Dataset):
    def __init__(self, image_dir, labels, transform=None):
        self.image_dir = image_dir
        self.labels = labels
        self.transform = transform
        self.image_names = os.listdir(image_dir)
        
    def __len__(self):
        return len(self.image_names)
    
    def __getitem__(self, idx):
        img_name = self.image_names[idx]
        img_path = os.path.join(self.image_dir, img_name)
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        label = self.labels[idx]
        
        return image, label

class XrayDataModule(L.LightningDataModule):
    def __init__(self, image_dir, labels, batch_size=4, transform=None, val_split=0.2):
        super().__init__()
        self.image_dir = image_dir
        self.labels = labels
        self.batch_size = batch_size
        self.transform = transform
        self.val_split = val_split

    def setup(self, stage=None):
        dataset_size = len(self.labels)
        val_size = int(dataset_size * self.val_split)
        train_size = dataset_size - val_size
        train_indices, val_indices = random_split(range(dataset_size), [train_size, val_size])
        
        # NEED TO USE TRAIN-INDICES AND VAL-INDICES TO SEPARATE THE TWO DATASETS
        # Create train and validation datasets
        self.dataset = XrayDataset(image_dir=self.image_dir, labels=self.labels, transform=self.transform)
        #self.val_dataset = XrayDataset(image_dir=self.image_dir, labels=self.labels, transform=self.transform)

    def train_dataloader(self):
        return DataLoader(self.dataset, batch_size=self.batch_size, shuffle=True)

    # def valid_dataloader(self):
    #     return DataLoader(self.dataset, batch_size=self.batch_size, shuffle=True)

def train_model(DATASET_PATH: Path, CHECKPOINT_PATH:Path, which_label:str='HAQ'):
    # Function for setting the seed
    L.seed_everything(42)

    # Ensure that all operations are dterministc on GPU for reproducibility
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = torch.device("cuda:0") if torch.cuda.is_available() else torch.device("cpu")

    # Create checkpoint path if it doesn't exist yet
    os.makedirs(CHECKPOINT_PATH, exist_ok=True)     

    # Define any transformations
    transform = transforms.Compose([
        transforms.Resize((128, 128)),
        transforms.ToTensor()
    ])

     # NEED TO DROP IF GREATERN THAN MAX VALUE FOR HAQ FIRST 
     # NEED A GENERALISABLE SOLUTION DEPENDENT ON OUTCOME CHOSEN TO TRAIN TO
    labels_df = pd.read_csv(DATASET_PATH / "dataframes" / "xrays_train.csv").dropna(subset=['HAQ'])

    data_module = XrayDataModule(image_dir=DATASET_PATH / "xray_images", labels=list(labels_df[which_label]), batch_size=4, transform=transform)
    data_module.setup()
    train_loader = data_module.train_dataloader()
    #val_loader = data_module.val_dataloader()

    model = DenseNetModel()
    trainer = L.Trainer(deterministic=True)

    trainer.fit(model, train_loader)

def main():
    DATASET_PATH = Path("/home/alix/Desktop/predict_haq/data")
    CHECKPOINT_PATH = Path("/home/alix/Desktop/predict_haq/checkpoints")
    train_model(DATASET_PATH, CHECKPOINT_PATH, 'HAQ')

if __name__ ==  "__main__":
    main()