import pandas as pd
from pathlib import Path
import os

def process_dataframe(path_to_data: Path, train_or_test: str):
    csv_name = "xray_" + train_or_test + ".csv"
    df = pd.read_csv(path_to_data / "dataframes" / csv_name)

    # Drop duplicates
    df = df.drop_duplicates(subset=["UID"]).reset_index(drop=True)

    # Keep rows that have a corresponding xray image
    df = df[[os.path.isfile(path_to_data/ "xray_images" / str(i)) for i in df['Filenames']]]

    return df